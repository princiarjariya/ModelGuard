<?php

declare(strict_types=1);

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function respond(int $status, array $data): never
{
    http_response_code($status);
    echo json_encode($data);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Allow: POST');
    respond(405, ['success' => false, 'message' => 'Method not allowed.']);
}

$submittedToken = $_POST['csrf_token'] ?? '';
if (
    !isset($_SESSION['csrf_token'])
    || !is_string($submittedToken)
    || !hash_equals($_SESSION['csrf_token'], $submittedToken)
) {
    respond(403, ['success' => false, 'message' => 'Your session expired. Refresh the page and try again.']);
}

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$eventType = $_POST['event_type'] ?? '';
$message = $_POST['message'] ?? '';

if (!is_string($name) || !is_string($email) || !is_string($eventType) || !is_string($message)) {
    respond(422, ['success' => false, 'message' => 'Please enter valid enquiry details.']);
}

$name = trim($name);
$email = trim($email);
$eventType = trim($eventType);

if (
    $name === ''
    || mb_strlen($name, 'UTF-8') > 255
    || !filter_var($email, FILTER_VALIDATE_EMAIL)
    || mb_strlen($email, 'UTF-8') > 255
    || $eventType === ''
    || mb_strlen($eventType, 'UTF-8') > 100
) {
    respond(422, ['success' => false, 'message' => 'Please enter a valid name, email, and event type.']);
}

require __DIR__ . '/connect.php';

try {
    // Public submissions have no account owner; keep the nullable legacy user_id empty.
    $statement = $pdo->prepare(
        'INSERT INTO enquiries (name, email, event_type, message)
         VALUES (:name, :email, :event_type, :message)'
    );
    $statement->execute([
        'name' => $name,
        'email' => $email,
        'event_type' => $eventType,
        'message' => $message,
    ]);
} catch (PDOException $exception) {
    error_log('Eventra enquiry submission failed: ' . $exception->getMessage());
    respond(500, [
        'success' => false,
        'message' => 'We could not save your enquiry. Please try again later.',
    ]);
}

respond(200, [
    'success' => true,
    'message' => 'Enquiry submitted successfully!',
]);
