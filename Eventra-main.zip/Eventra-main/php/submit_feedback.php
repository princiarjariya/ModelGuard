<?php

declare(strict_types=1);

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function respond(int $status, array $data): never
{
    http_response_code($status);
    echo json_encode($data);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Allow: POST');
    respond(405, ['message' => 'Method not allowed.']);
}

$submittedToken = $_POST['csrf_token'] ?? '';
if (
    !isset($_SESSION['csrf_token'])
    || !is_string($submittedToken)
    || !hash_equals($_SESSION['csrf_token'], $submittedToken)
) {
    respond(403, ['message' => 'Your session expired. Refresh the page and try again.']);
}

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$rating = $_POST['rating'] ?? '';
$message = $_POST['message'] ?? '';

if (!is_string($name) || !is_string($email) || !is_string($rating) || !is_string($message)) {
    respond(422, ['message' => 'Please enter valid feedback details.']);
}

$name = trim($name);
$email = trim($email);
$message = trim($message);
$ratingValue = filter_var($rating, FILTER_VALIDATE_INT);

if (
    $name === ''
    || mb_strlen($name, 'UTF-8') > 255
    || !filter_var($email, FILTER_VALIDATE_EMAIL)
    || mb_strlen($email, 'UTF-8') > 255
    || $ratingValue === false
    || $ratingValue < 1
    || $ratingValue > 5
    || $message === ''
    || mb_strlen($message, 'UTF-8') > 5000
) {
    respond(422, ['message' => 'Enter a name, valid email, rating from 1 to 5, and feedback up to 5,000 characters.']);
}

require __DIR__ . '/connect.php';

try {
    // Feedback is submitted by visitors, not by signed-in user accounts.
    $statement = $pdo->prepare(
        'INSERT INTO feedback (name, email, rating, message)
         VALUES (:name, :email, :rating, :message)'
    );
    $statement->execute([
        'name' => $name,
        'email' => $email,
        'rating' => $ratingValue,
        'message' => $message,
    ]);
} catch (PDOException $exception) {
    error_log('Eventra feedback submission failed: ' . $exception->getMessage());
    respond(500, ['message' => 'We could not save your feedback. Please try again later.']);
}

respond(201, ['message' => 'Thank you for sharing your feedback!']);
