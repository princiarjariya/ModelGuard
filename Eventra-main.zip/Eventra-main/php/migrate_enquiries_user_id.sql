ALTER TABLE enquiries
  ADD COLUMN user_id INT UNSIGNED NULL AFTER id,
  ADD KEY enquiries_user_id_idx (user_id),
  ADD CONSTRAINT enquiries_user_id_fk
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE SET NULL
    ON UPDATE CASCADE;

UPDATE enquiries AS enquiry
JOIN users AS account
  ON account.email COLLATE utf8mb4_unicode_ci = enquiry.email COLLATE utf8mb4_unicode_ci
SET enquiry.user_id = account.id
WHERE enquiry.user_id IS NULL;