<?php

declare(strict_types=1);

session_start();
header('Cache-Control: no-store');
require __DIR__ . '/php/connect.php';

if (!isset($_SESSION['admin_csrf_token']) || !is_string($_SESSION['admin_csrf_token'])) {
    $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
}

// Only these credentials can access the enquiry and feedback dashboard.
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'Admin@12345678';

$errorMessage = '';
$isAdmin = ($_SESSION['admin_authenticated'] ?? false) === true;

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $submittedToken = $_POST['csrf_token'] ?? '';
    if (
        !is_string($submittedToken)
        || !hash_equals($_SESSION['admin_csrf_token'], $submittedToken)
    ) {
        http_response_code(403);
        exit('Your session expired. Refresh the page and try again.');
    }

    $action = $_POST['action'] ?? '';
    if ($action === 'logout' && $isAdmin) {
        unset($_SESSION['admin_authenticated'], $_SESSION['admin_username']);
        session_regenerate_id(true);
        $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
        header('Location: admin.php');
        exit;
    }

    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    if (
        $action !== 'login'
        || !is_string($username)
        || !is_string($password)
        || !hash_equals(ADMIN_USERNAME, $username)
        || !hash_equals(ADMIN_PASSWORD, $password)
    ) {
        $errorMessage = 'The username or password is incorrect.';
    } else {
        session_regenerate_id(true);
        $_SESSION['admin_authenticated'] = true;
        $_SESSION['admin_username'] = ADMIN_USERNAME;
        $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
        header('Location: admin.php');
        exit;
    }
}

$csrfToken = htmlspecialchars($_SESSION['admin_csrf_token'], ENT_QUOTES, 'UTF-8');
$adminUsernameEscaped = htmlspecialchars($_SESSION['admin_username'] ?? '', ENT_QUOTES, 'UTF-8');
$enquiries = [];
$feedbackEntries = [];

// Load every contact and feedback record only after the admin is authenticated.
if ($isAdmin) {
    try {
        $enquiries = $pdo->query(
            'SELECT id, name, email, event_type, message, created_at
             FROM enquiries
             ORDER BY created_at DESC, id DESC'
        )->fetchAll();
        $feedbackEntries = $pdo->query(
            'SELECT id, name, email, rating, message, created_at
             FROM feedback
             ORDER BY created_at DESC, id DESC'
        )->fetchAll();
    } catch (PDOException $exception) {
        error_log('Eventra admin dashboard load failed: ' . $exception->getMessage());
        http_response_code(500);
        exit('We could not load admin data right now. Please try again later.');
    }
}

function escapeHtml(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function renderEmptyRow(int $columnCount, string $message): void
{
    echo '<tr><td colspan="' . $columnCount . '">' . escapeHtml($message) . '</td></tr>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Eventra Admin</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="admin-page">
<!-- Guests never authenticate here; this page exposes the dashboard only to the admin session. -->
<?php if (!$isAdmin): ?>
  <main class="admin-auth">
    <a class="dashboard-brand" href="index.html">Event<span>ra</span></a>
    <section class="admin-auth-card">
      <p class="section-kicker">Eventra management</p>
      <h1>Admin sign in</h1>
      <p class="admin-auth-intro">Sign in to manage user accounts, enquiries, and guest feedback.</p>
      <?php if ($errorMessage !== ''): ?>
        <p class="admin-error" role="alert"><?= escapeHtml($errorMessage) ?></p>
      <?php endif; ?>
      <form class="admin-auth-form" method="post" action="admin.php">
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
        <input type="hidden" name="action" value="login">
        <label for="admin-username">Username</label>
        <input id="admin-username" name="username" type="text" maxlength="50" autocomplete="username" required>
        <label for="admin-password">Password</label>
        <input id="admin-password" name="password" type="password" maxlength="255" autocomplete="current-password" required>
        <button type="submit">Log in</button>
      </form>
      <a class="admin-home-link" href="index.html">Return to Eventra</a>
    </section>
  </main>
<?php else: ?>
  <header class="admin-header">
    <a class="dashboard-brand" href="admin.php">Event<span>ra</span> <small>ADMIN</small></a>
    <div class="admin-header-actions">
      <span><?= $adminUsernameEscaped ?></span>
      <a href="index.html">View website</a>
      <form method="post" action="admin.php">
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
        <input type="hidden" name="action" value="logout">
        <button type="submit">Log out</button>
      </form>
    </div>
  </header>
  <main class="admin-content">
    <section class="admin-hero">
      <div>
        <p class="section-kicker">EVENTRA CONTROL ROOM</p>
        <h1>Good to see you,<br><span><?= $adminUsernameEscaped ?>.</span></h1>
        <p>Every event enquiry and guest feedback submission, together in one place.</p>
      </div>
      <div class="admin-hero-side">
        <span class="admin-live-dot"></span>
        <span>Live database</span>
        <strong><?= count($enquiries) + count($feedbackEntries) ?></strong>
        <small>total records</small>
      </div>
    </section>
    <section class="admin-stats" aria-label="Record totals">
      <a class="admin-stat-enquiries" href="#enquiries"><span class="admin-stat-icon">✉</span><small>INBOX</small><strong><?= count($enquiries) ?></strong><span>Event enquiries <b>→</b></span></a>
      <a class="admin-stat-feedback" href="#feedback"><span class="admin-stat-icon">★</span><small>GUEST VOICES</small><strong><?= count($feedbackEntries) ?></strong><span>Feedback submissions <b>→</b></span></a>
    </section>

    <nav class="admin-section-nav" aria-label="Dashboard sections">
      <a href="#enquiries">Enquiries <span><?= count($enquiries) ?></span></a>
      <a href="#feedback">Feedback <span><?= count($feedbackEntries) ?></span></a>
      <label class="admin-search">
        <span aria-hidden="true">⌕</span>
        <input id="admin-search" type="search" placeholder="Search all records..." aria-label="Search all records">
        <button id="admin-search-clear" type="button" aria-label="Clear search" hidden>&times;</button>
      </label>
    </nav>

    <section class="admin-data-section" id="enquiries">
      <div class="admin-section-heading"><div><p class="admin-section-eyebrow">LET'S MAKE IT HAPPEN</p><h2>Event enquiries</h2></div><span><?= count($enquiries) ?> submissions <small>· all records</small></span></div>
      <div class="admin-table-wrap"><table>
        <thead><tr><th>Guest</th><th>Event type</th><th>Enquiry message</th><th>Received</th></tr></thead>
        <tbody>
        <?php if ($enquiries === []): renderEmptyRow(4, 'No enquiries have been submitted yet.'); ?>
        <?php else: foreach ($enquiries as $enquiry): ?>
          <tr>
            <td class="admin-person"><span class="admin-avatar"><?= escapeHtml(strtoupper(substr($enquiry['name'], 0, 1))) ?></span><div><strong><?= escapeHtml($enquiry['name']) ?></strong><a class="admin-contact-link" href="mailto:<?= escapeHtml($enquiry['email']) ?>"><?= escapeHtml($enquiry['email']) ?></a><span class="admin-record-note">Contact submission</span></div></td>
            <td><span class="admin-event-badge"><?= escapeHtml($enquiry['event_type']) ?></span></td>
            <td class="admin-long-text"><?= $enquiry['message'] !== '' ? escapeHtml($enquiry['message']) : '<span class="admin-muted">No message provided</span>' ?></td>
            <td><time><?= escapeHtml($enquiry['created_at']) ?></time></td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table></div>
    </section>

    <section class="admin-data-section" id="feedback">
      <div class="admin-section-heading"><div><p class="admin-section-eyebrow">STRAIGHT FROM YOUR GUESTS</p><h2>Guest feedback</h2></div><span><?= count($feedbackEntries) ?> submissions <small>· all records</small></span></div>
      <div class="admin-table-wrap"><table>
        <thead><tr><th>Guest</th><th>Rating</th><th>Feedback message</th><th>Received</th></tr></thead>
        <tbody>
        <?php if ($feedbackEntries === []): renderEmptyRow(4, 'No feedback submissions have been received yet.'); ?>
        <?php else: foreach ($feedbackEntries as $entry): ?>
          <tr>
            <td class="admin-person"><span class="admin-avatar admin-avatar-feedback"><?= escapeHtml(strtoupper(substr($entry['name'], 0, 1))) ?></span><div><strong><?= escapeHtml($entry['name']) ?></strong><a class="admin-contact-link" href="mailto:<?= escapeHtml($entry['email']) ?>"><?= escapeHtml($entry['email']) ?></a><span class="admin-record-note">Feedback submission</span></div></td>
            <td><span class="admin-rating"><?= str_repeat('★', (int) $entry['rating']) ?><small><?= (int) $entry['rating'] ?>/5</small></span></td>
            <td class="admin-long-text"><?= escapeHtml($entry['message']) ?></td>
            <td><time><?= escapeHtml($entry['created_at']) ?></time></td>
          </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table></div>
    </section>
    <p class="admin-filter-empty" id="admin-filter-empty" hidden>No records match your search. Try another name, email, event type, or message.</p>
    <p class="admin-footer-note">Eventra Admin <span>·</span> Showing every record in the database</p>
  </main>
<?php endif; ?>
<?php if ($isAdmin): ?>
<script src="assets/js/admin.js"></script>
<?php endif; ?>
</body>
</html>
