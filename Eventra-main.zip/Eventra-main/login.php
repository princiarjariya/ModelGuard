<?php

declare(strict_types=1);

header('Cache-Control: no-store');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    header('Allow: GET');
    http_response_code(405);
    exit('User login is not available. Use the admin sign-in page to access dashboard data.');
}

header('Location: admin.php', true, 302);
exit;
