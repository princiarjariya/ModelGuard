-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2026 at 06:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventra`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_accounts`
--

CREATE TABLE `admin_accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(254) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_accounts`
--

INSERT INTO `admin_accounts` (`id`, `email`, `password_hash`, `created_at`) VALUES
(1, 'khushbu@gmail.com', '$2y$10$WvvvOa29T7RaJqNFqrhGQezXuX8jpUMz0VaXdyKs21uL7cChS5TvW', '2026-10-16 14:13:33');

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `id` int(11) NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquiries`
--

INSERT INTO `enquiries` (`id`, `user_id`, `name`, `email`, `event_type`, `message`, `created_at`) VALUES
(1, 3, 'khushbu', 'khushboochaurasia457@gmail.com', 'Wedding', 'please contact me for any birthdays event and marrige events', '2026-10-06 06:35:27'),
(2, 3, 'khushbu', 'khushboochaurasia457@gmail.com', 'Wedding', 'please contact me for any birthdays event and marrige events', '2026-10-06 06:36:40'),
(3, 4, 'aditya', 'madhurichaurasia372@gmail.com', 'Birthday', 'happy birthday aditya', '2026-10-06 06:51:43'),
(4, 3, 'ajay', 'khushboochaurasia457@gmail.com', 'Corporate event', ' invited', '2026-10-09 07:05:58'),
(7, NULL, 'princi', 'princi23@gmail.com', 'Corporate event', 'invited', '2026-10-09 07:37:56'),
(11, NULL, 'princi', 'princi13@gmail.com', 'Wedding', 'invited', '2026-10-09 07:44:23'),
(12, NULL, 'vyas', 'aditya13@gamil.com', 'Corporate event', 'hiii', '2026-10-09 07:54:38'),
(13, NULL, 'princi', 'princi56@gmail.com', 'Wedding', 'invited', '2026-10-09 08:00:06'),
(14, 6, 'khushbu chaurasia', 'princi@gmail.com', 'Wedding', 'invited', '2026-10-12 14:41:37'),
(15, 6, 'khushbu chaurasia', 'princi@gmail.com', 'Corporate event', 'you are invited', '2026-10-12 14:45:34'),
(16, 7, 'khushu', 'khushu@gmail.com', 'Birthday', 'hbd', '2026-10-12 15:29:05'),
(17, 7, 'khushu', 'khushu@gmail.com', 'Birthday', 'happiest birthday', '2026-10-12 15:30:16'),
(18, 3, 'princi', 'khushboochaurasia457@gmail.com', 'Birthday', 'hbd', '2026-10-13 05:21:08'),
(19, 3, 'ajay', 'abc@gmail.com', 'Wedding', 'enjoy', '2026-10-13 05:22:57'),
(20, 3, 'khushbu chaurasia', 'khushboochaurasia457@gmail.com', 'Corporate event', 'invited', '2026-10-16 14:19:11'),
(21, 3, 'khushbu chaurasia', 'khushboochaurasia457@gmail.com', 'Corporate event', 'invited', '2026-10-16 14:19:27'),
(22, 3, 'khushbu chaurasia', 'khushboochaurasia457@gmail.com', 'Corporate event', 'invited', '2026-10-16 14:19:59'),
(25, NULL, 'princi', 'princi@gmail.com', 'Birthday', 'hbd', '2026-10-16 15:40:58');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `rating` tinyint(3) UNSIGNED NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `name`, `email`, `rating`, `message`, `created_at`) VALUES
(1, 3, 'khushbu', 'khushboochaurasia457@gmail.com', 5, 'good', '2026-10-16 15:54:45'),
(2, 3, 'khushbu', 'khushboochaurasia457@gmail.com', 5, 'good', '2026-10-16 15:55:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_accounts_email_unique` (`email`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `enquiries_user_id_idx` (`user_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feedback_user_id_idx` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_accounts`
--
ALTER TABLE `admin_accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD CONSTRAINT `enquiries_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
