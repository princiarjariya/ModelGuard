if (window.location.protocol === 'file:' || window.location.port === '5500') {
  const xamppUrl = new URL('http://localhost/Eventra/');
  xamppUrl.hash = window.location.hash;
  window.location.replace(xamppUrl.href);
}

// Mobile navigation expands and collapses the section links.
const menuToggle = document.querySelector('.menu-toggle');
const navbar = document.querySelector('.navbar');

// Mobile navigation: keep the menu state and accessibility label in sync.
menuToggle?.addEventListener('click', () => {
  const isOpen = navbar.classList.toggle('menu-open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});

// Hero carousel: coordinate the visible slide, arrows, and indicators.
const slides = [...document.querySelectorAll('.hero-slide')];
const indicators = [...document.querySelectorAll('.hero-indicator')];
const hero = document.querySelector('.hero');
let activeSlide = Math.max(0, slides.findIndex((slide) => slide.classList.contains('is-active')));
let slideTimer;

const showSlide = (index) => {
  if (!slides.length) return;
  slides.forEach((slide, slideIndex) => {
    const isActive = slideIndex === (index + slides.length) % slides.length;
    slide.classList.toggle('is-active', isActive);
    slide.setAttribute('aria-hidden', String(!isActive));
    indicators[slideIndex]?.classList.toggle('is-active', isActive);
    indicators[slideIndex]?.setAttribute('aria-current', isActive ? 'true' : 'false');
  });
  activeSlide = (index + slides.length) % slides.length;
};

document
  .querySelector('.hero-arrow-left')
  ?.addEventListener('click', () => showSlide(activeSlide - 1));
document
  .querySelector('.hero-arrow-right')
  ?.addEventListener('click', () => showSlide(activeSlide + 1));
indicators.forEach((indicator, index) => {
  indicator.addEventListener('click', () => showSlide(index));
});
showSlide(activeSlide);

// Pause autoplay while the pointer is over the hero and resume when it leaves.
const startSlideTimer = () => {
  if (slides.length > 1 && !slideTimer) {
    slideTimer = setInterval(() => showSlide(activeSlide + 1), 5000);
  }
};

const stopSlideTimer = () => {
  clearInterval(slideTimer);
  slideTimer = null;
};

hero?.addEventListener('mouseenter', stopSlideTimer);
hero?.addEventListener('mouseleave', startSlideTimer);
startSlideTimer();

// Gallery viewer: open any thumbnail and advance to the next photo every 3 seconds.
const galleryThumbnails = [...document.querySelectorAll('.gallery-thumbnail')];
const galleryViewer = document.querySelector('.gallery-viewer');
const galleryViewerImage = document.querySelector('.gallery-viewer-image');
const galleryViewerCount = document.querySelector('.gallery-viewer-count');
let activeGalleryPhoto = 0;
let galleryViewerTimer;
let galleryTouchStartX = null;
let galleryReturnFocus;

const showGalleryPhoto = (index) => {
  if (!galleryThumbnails.length) return;

  activeGalleryPhoto = (index + galleryThumbnails.length) % galleryThumbnails.length;
  const thumbnailImage = galleryThumbnails[activeGalleryPhoto].querySelector('img');
  galleryViewerImage.src = thumbnailImage.src.replace(/w=700/, 'w=1600');
  galleryViewerImage.alt = thumbnailImage.alt;
  galleryViewerCount.textContent = `${activeGalleryPhoto + 1} / ${galleryThumbnails.length}`;
};

const closeGalleryViewer = () => {
  galleryViewer.hidden = true;
  document.body.classList.remove('gallery-viewer-open');
  clearInterval(galleryViewerTimer);
  galleryViewerTimer = null;
  galleryReturnFocus?.focus();
};

const openGalleryViewer = (index) => {
  galleryReturnFocus = galleryThumbnails[index];
  showGalleryPhoto(index);
  galleryViewer.hidden = false;
  document.body.classList.add('gallery-viewer-open');
  clearInterval(galleryViewerTimer);
  galleryViewerTimer = setInterval(() => showGalleryPhoto(activeGalleryPhoto + 1), 3000);
  galleryViewer.querySelector('.gallery-viewer-close').focus();
};

galleryThumbnails.forEach((thumbnail, index) => {
  thumbnail.addEventListener('click', () => openGalleryViewer(index));
});
document.querySelector('.gallery-viewer-close')
  ?.addEventListener('click', closeGalleryViewer);
document.querySelector('.gallery-viewer-prev')
  ?.addEventListener('click', () => showGalleryPhoto(activeGalleryPhoto - 1));
document.querySelector('.gallery-viewer-next')
  ?.addEventListener('click', () => showGalleryPhoto(activeGalleryPhoto + 1));
galleryViewer?.addEventListener('click', (event) => {
  if (event.target === galleryViewer) closeGalleryViewer();
});
galleryViewer?.addEventListener('touchstart', (event) => {
  galleryTouchStartX = event.changedTouches[0].clientX;
}, { passive: true });
galleryViewer?.addEventListener('touchend', (event) => {
  if (galleryTouchStartX === null) return;
  const swipeDistance = event.changedTouches[0].clientX - galleryTouchStartX;
  if (Math.abs(swipeDistance) > 50) {
    showGalleryPhoto(activeGalleryPhoto + (swipeDistance < 0 ? 1 : -1));
  }
  galleryTouchStartX = null;
}, { passive: true });
document.addEventListener('keydown', (event) => {
  if (galleryViewer?.hidden) return;
  if (event.key === 'Escape') closeGalleryViewer();
  if (event.key === 'ArrowRight') showGalleryPhoto(activeGalleryPhoto + 1);
  if (event.key === 'ArrowLeft') showGalleryPhoto(activeGalleryPhoto - 1);
});

// Feedback carousel: rotate guest reviews every three seconds with manual controls.
const feedbackSlides = [...document.querySelectorAll('.feedback-slide')];
const feedbackIndicators = [...document.querySelectorAll('.feedback-indicator')];
const feedbackCarousel = document.querySelector('.feedback-carousel');
const feedbackInterval = 3000;
let activeFeedback = 0;
let feedbackTimer;

const showFeedback = (index) => {
  if (!feedbackSlides.length) return;

  activeFeedback = (index + feedbackSlides.length) % feedbackSlides.length;
  feedbackSlides.forEach((slide, slideIndex) => {
    const isActive = slideIndex === activeFeedback;
    slide.hidden = !isActive;
    slide.setAttribute('aria-hidden', String(!isActive));
    slide.classList.toggle('is-active', isActive);
    feedbackIndicators[slideIndex]?.classList.toggle('is-active', isActive);
    feedbackIndicators[slideIndex]?.setAttribute('aria-current', String(isActive));
  });
};

const startFeedbackTimer = () => {
  if (feedbackSlides.length > 1 && !feedbackTimer) {
    feedbackTimer = setInterval(() => showFeedback(activeFeedback + 1), feedbackInterval);
  }
};

const stopFeedbackTimer = () => {
  clearInterval(feedbackTimer);
  feedbackTimer = null;
};

document
  .querySelector('.feedback-arrow-left')
  ?.addEventListener('click', () => showFeedback(activeFeedback - 1));
document
  .querySelector('.feedback-arrow-right')
  ?.addEventListener('click', () => showFeedback(activeFeedback + 1));
feedbackIndicators.forEach((indicator, index) => {
  indicator.addEventListener('click', () => showFeedback(index));
});
feedbackCarousel?.addEventListener('mouseenter', stopFeedbackTimer);
feedbackCarousel?.addEventListener('mouseleave', startFeedbackTimer);
feedbackCarousel?.addEventListener('focusin', stopFeedbackTimer);
feedbackCarousel?.addEventListener('focusout', (event) => {
  if (!feedbackCarousel.contains(event.relatedTarget)) startFeedbackTimer();
});
showFeedback(activeFeedback);
startFeedbackTimer();

// Theme control: apply the chosen mode and update its accessible state.
const themeToggle = document.querySelector('.theme-toggle');
const themeIcon = document.querySelector('.theme-icon');

const setDarkMode = (isDark) => {
  document.body.classList.toggle('dark-mode', isDark);
  themeToggle?.setAttribute('aria-pressed', String(isDark));
  themeToggle?.setAttribute('aria-label', isDark ? 'Disable dark mode' : 'Enable dark mode');
  if (themeIcon) themeIcon.textContent = isDark ? '☀' : '☾';
};

themeToggle?.addEventListener('click', () => {
  setDarkMode(!document.body.classList.contains('dark-mode'));
});

// Restore the visitor's saved theme, falling back when storage is unavailable.
try {
  setDarkMode(localStorage.getItem('eventra-theme') === 'dark');
} catch (error) {
  setDarkMode(false);
}

// Remember theme changes when browser storage is available.
themeToggle?.addEventListener('click', () => {
  try {
    localStorage.setItem('eventra-theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
  } catch (error) {
    // Dark mode still works when browser storage is unavailable.
  }
});

// Schedule tab controls map each selected day to its matching panel.
const tabs = document.querySelectorAll('.schedule-tab');
const panels = document.querySelectorAll('.schedule-panel');

// Schedule tabs: show only the panel selected by the visitor.
tabs.forEach((tab) => tab.addEventListener('click', () => {
  tabs.forEach((item) => item.classList.toggle('is-active', item === tab));
  panels.forEach((panel) => {
    panel.hidden = panel.id !== tab.dataset.day;
  });
}));

// Public enquiry and feedback forms share a server-issued CSRF token, not a user login.
const form = document.querySelector('#registration-form');
const feedbackForm = document.querySelector('#feedback-form');
let formCsrfToken = '';

form?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = form.querySelector('.form-message');
  const submitButton = form.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  message.textContent = 'Sending your enquiry...';

  try {
    const response = await fetch(form.action, {
      method: 'POST',
      body: new FormData(form),
      headers: { Accept: 'application/json' },
    });
    const responseText = await response.text();
    let result;

    try {
      result = JSON.parse(responseText);
    } catch {
      const isPhpSource = responseText.trimStart().startsWith('<?php');
      throw new Error(isPhpSource
        ? 'This page is not running through XAMPP. Open http://localhost/Eventra/ and try again.'
        : 'The server returned an invalid response. Please refresh the page and try again.');
    }

    if (!response.ok) {
      throw new Error(result.message || 'Your enquiry could not be sent. Please try again.');
    }

    message.textContent = result.message;
    form.reset();
    form.querySelector('[name="csrf_token"]').value = formCsrfToken;
  } catch (error) {
    message.textContent = error.message || 'Unable to connect to the server. Please try again.';
  } finally {
    submitButton.disabled = false;
  }
});

feedbackForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const status = feedbackForm.querySelector('.feedback-form-message');
  const submitButton = feedbackForm.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  status.textContent = 'Sending your feedback…';
  status.classList.remove('is-error');

  try {
    const response = await fetch(feedbackForm.action, {
      method: 'POST',
      body: new FormData(feedbackForm),
      headers: { Accept: 'application/json' },
    });
    let result;
    try {
      result = await response.json();
    } catch {
      throw new Error('The server returned an invalid response. Please refresh the page and try again.');
    }
    if (!response.ok) throw new Error(result.message || 'Your feedback could not be sent.');
    status.textContent = result.message;
    feedbackForm.reset();
    feedbackForm.querySelector('[name="csrf_token"]').value = formCsrfToken;
  } catch (error) {
    status.textContent = error.message || 'Unable to connect to the server. Please try again.';
    status.classList.add('is-error');
  } finally {
    submitButton.disabled = false;
  }
});

fetch('php/session_token.php', { headers: { Accept: 'application/json' } })
  .then(async (response) => {
    const result = await response.json();
    if (!response.ok || typeof result.csrf_token !== 'string') {
      throw new Error(result.message || 'The form service is unavailable.');
    }
    formCsrfToken = result.csrf_token;
    const enquiryCsrf = form?.querySelector('[name="csrf_token"]');
    if (enquiryCsrf) enquiryCsrf.value = formCsrfToken;
    const feedbackCsrf = feedbackForm?.querySelector('[name="csrf_token"]');
    if (feedbackCsrf) feedbackCsrf.value = formCsrfToken;
  })
  .catch((error) => {
    const enquiryMessage = form?.querySelector('.form-message');
    if (enquiryMessage) enquiryMessage.textContent = error.message || 'The form service is unavailable.';
    const feedbackMessage = feedbackForm?.querySelector('.feedback-form-message');
    if (feedbackMessage) {
      feedbackMessage.textContent = error.message || 'The form service is unavailable.';
      feedbackMessage.classList.add('is-error');
    }
  });
