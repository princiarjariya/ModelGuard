// Search guest enquiries and feedback without leaving the dashboard.
const searchInput = document.querySelector('#admin-search');
const clearSearch = document.querySelector('#admin-search-clear');
const filterEmpty = document.querySelector('#admin-filter-empty');
const searchableRows = [...document.querySelectorAll('.admin-table-wrap tbody tr')].filter(
  (row) => !row.querySelector('[colspan]')
);

const filterRecords = () => {
  const query = searchInput.value.trim().toLocaleLowerCase();
  let visibleRows = 0;

  searchableRows.forEach((row) => {
    const matches = row.textContent.toLocaleLowerCase().includes(query);
    row.hidden = !matches;
    if (matches) visibleRows += 1;
  });

  document.querySelectorAll('.admin-data-section').forEach((section) => {
    const sectionRows = [...section.querySelectorAll('tbody tr')].filter(
      (row) => !row.querySelector('[colspan]')
    );
    section.hidden = query !== '' && !sectionRows.some((row) => !row.hidden);
  });

  filterEmpty.hidden = query === '' || visibleRows > 0;
  clearSearch.hidden = query === '';
};

searchInput?.addEventListener('input', filterRecords);
clearSearch?.addEventListener('click', () => {
  searchInput.value = '';
  filterRecords();
  searchInput.focus();
});
